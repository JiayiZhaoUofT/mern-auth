module.exports = {
  mongoURI:
    "mongodb+srv://user1:12345@mern-lftlp.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey: "secret"
};
